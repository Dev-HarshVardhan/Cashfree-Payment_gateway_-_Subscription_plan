<?php
include '../admin/include/connection.php';

/*
API VERSION:
2022-09-01 : get the payment_session id for create your own custom checkout page
2021-05-21 or 2022-01-01 : get the payment link for cashfree checkout system
*/

$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL => "https://sandbox.cashfree.com/pg/orders/" . $_GET['order_id'],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => [
        "accept: application/json",
        "x-api-version: 2021-05-21",
        "x-client-id: TEST10218286366f44fbb7f0cf705b4c68281201",
        "x-client-secret: cfsk_ma_test_ba23e6f2b24af5c1059d7f1b53c72722_78cec48c"
    ],
]);

$response = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);

if ($err) {
    echo "cURL Error #:" . $err;
} else {
    $response = json_decode($response, true);
}

// print_r($response);
// exit;
// Get user IP
$user_ip = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];


if (isset($response['order_status']) && $response['order_status'] == 'PAID') {


    $order_id = $response['order_id'];
    $query_run = "update  order_tbl set payment_status='success' where order_id='$order_id'";
    $result1 = mysqli_query($conn, $query_run);
    if ($result1) {

        $sql = "Delete from cart where user_ip='$user_ip'";
        $res = mysqli_query($conn, $sql);

        require '../PHPMailer/src/Exception.php';
        require '../PHPMailer/src/PHPMailer.php';
        require '../PHPMailer/src/SMTP.php';

        $order_query = "SELECT * FROM order_tbl WHERE order_id = '$order_id'";
        $order_result = mysqli_query($conn, $order_query);



        if ($order_result && mysqli_num_rows($order_result) > 0) {
            $record = mysqli_fetch_assoc($order_result);
            $total_amount = $record['total_amount'];
            $pdf = explode(', ', $record['pdf']);
            $product_id = $record['product_id'];
            $address = $record['address'];
            $city = $record['city'];
            $phone = $record['phone'];
            $email = $record['email'];
            $name = $record['name'];


            foreach ($pdf as $key => $value) {
                ${"pdf_$key"} = $value;
            }

            $product_names = explode(', ', $record['product_name']);

            // Loop through $product_names array and assign each value to a variable
            foreach ($product_names as $key => $value) {
                ${"product_name_$key"} = $value;
            }

            // Initialize PHPMailer
            $mail = new PHPMailer\PHPMailer\PHPMailer();
            
            // $mail->SMTPDebug=2;

            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'hs360863@gmail.com';
            $mail->Password = 'cjibhfyesqbflcwn';
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            $mail->setFrom('hs360863@gmail.com', 'Wealthplus');
            $mail->addAddress($email);
            $mail->Subject = 'Payment Successful';


            $data = array(
                "Name" => $name,
                "Email" => $email,
                "Phone" => $phone,
                "City" => $city,
                "Address" => $address,
                "Product Name" => implode(', ', $product_names),
                "Message" => "Subscription created and activated successfully."
            );


            // Construct links for each PDF
            $pdf_links = '';
            foreach ($pdf as $pdf_file) {
                $pdf_links .= '<a href="' . base_url . 'admin/product/images/' . $pdf_file . '">' . $pdf_file . '</a><br></br>';
                echo "<br>";
            }
            $data["PDFs"] = $pdf_links;

            $table = "<table style='border-collapse: collapse;'>";
            foreach ($data as $key => $value) {
                $table .= "<tr><th style='border: 1px solid black; padding: 5px;'>" . $key . "</th><td style='border: 1px solid black; padding: 5px;'>" . $value . "</td></tr>";
            }
            $table .= "</table>";
            $table .= '<p>Mutual Fund investments are subject to market risks, read all scheme related documents carefully. Please refer to our <a href="https://wealthplys.com/terms-and-conditions.php">Terms and Conditions</a> and <a href="https://wealthplys.com/disclaimer.php">Disclaimer</a> for more information.</p>';


            $html_body = "<h1>Information</h1>" . $table;

            $mail->msgHTML($html_body);

            

           

            if ($mail->send()) {
                
                $plan_result = createPlan();
                if ($plan_result) {
                    createSubscription($name, $email, $phone, 'INR');
                }
                // header("location:thanku1.php");
            }else{
                echo 'Email not Sent';
            }


           
        } else {
            echo "Order not found.";
        }
    } else {
        echo 'Data Not Update';
    }
} else {

    $order_id = $response['order_id'];
    $query = "update  order_tbl set payment_status='Failure' where order_id='$order_id'";
    $result = mysqli_query($conn, $query);
    if ($result) {
        header("location:../checkout.php");
    } else {
        header("location:../checkout.php");
    }
}

function createPlan()
{
    global $plan_ids;

    $planData = [
        "plan_id" => "plan_" . rand(10000, 99999),
        "plan_name" => "Plan_" . rand(10000, 99999),
        "plan_type" => "PERIODIC",
        "plan_currency" => "INR",
        "plan_recurring_amount" => 10,
        "plan_max_amount" => 100,
        "plan_max_cycles" => 10,
        "plan_intervals" => 2,
        "plan_interval_type" => "WEEK",
        "plan_note" => "Test Plan333"
    ];

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://sandbox.cashfree.com/pg/plans",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            "accept: application/json",
            "content-type: application/json",
            "x-api-version: 2023-08-01",
            "x-client-id: TEST10265389473c63c4f97a19330e0698356201",  // Move credentials to environment variables
            "x-client-secret: cfsk_ma_test_e655e053fa44005485578ad058e5b93d_c15ce340"
        ],
        CURLOPT_POSTFIELDS => json_encode($planData)
    ]);

    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);

    if ($err) {
        echo "Plan Creation cURL Error #:" . $err;
        return false;
    } else {
        $plan_result = json_decode($response, true);

        if (isset($plan_result['plan_status']) && $plan_result['plan_status'] == 'ACTIVE') {
            $plan_ids = $plan_result['plan_id'];
            echo "Plan created successfully.";
            return true;
        } else {
            echo "Plan creation failed.";
            echo "<pre>";
            print_r($plan_result);
            echo "</pre>";
            return false;
        }
    }
}

function createSubscription($name, $email, $phone, $currency)
{
    global $plan_ids;

    if (empty($email) || empty($phone)) {
        echo "Email and phone are required fields.";
        return;
    }

    $subscription_id = 'Subs_' . rand(111, 999);

    $subscriptionData = [
        'subscriptionId' => $subscription_id,
        'planId' => $plan_ids,
        'customerName' => $name,
        'customerPhone' => $phone,
        'customerEmail' => $email,
        'returnUrl' => 'http://localhost/wealth/pay/response.php',
        'authAmount' => 1,
        'expiresOn' => date("Y-m-d H:i:s", strtotime("+20 year")),
        'firstChargeDate' => date("Y-m-d", strtotime("+1 year")),
        'payerAccountDetails' => [
            'accountNumber' => '007200000000',
            'accountHolderName' => $name,
            'bankId' => 'ICIC',
            'accountType' => 'SAVINGS',
            'ifsc' => 'ICIC0000072'
        ],
        'notificationChannels' => ['EMAIL', 'SMS'],
    ];

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://test.cashfree.com/api/v2/subscriptions/seamless/subscription",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            "accept: application/json",
            "content-type: application/json",
            "x-api-version: 2023-08-01",
            "x-client-id: TEST10265389473c63c4f97a19330e0698356201",
            "x-client-secret: cfsk_ma_test_e655e053fa44005485578ad058e5b93d_c15ce340"
        ],
        CURLOPT_POSTFIELDS => json_encode($subscriptionData)
    ]);

    $subscription_response = curl_exec($curl);
    $subscription_err = curl_error($curl);
    curl_close($curl);

    if ($subscription_err) {
        echo "Subscription cURL Error #:" . $subscription_err;
    } else {
        $subscription_result = json_decode($subscription_response, true);

        if (isset($subscription_result['status']) && $subscription_result['status'] == 200) {
            header("location:thanku1.php");
            // echo "Subscription created and activated successfully.";
            // echo "<pre>";
            // print_r($subscription_result);
            // echo "<pre></pre>";
        } else {
            echo "Subscription creation failed or is not active.";
        }
    }
}
